/* =========================================================
   Sesivoting.js
   Logic untuk admin/sesi-voting.html — mengelola sesi voting lewat smart contract
   VotingSession, memantau relayer & antrian suara, dan menampilkan hasil akhir.

   Alur singkat:
   1. Status sesi, jumlah suara, dan hasil DIBACA dari blockchain (RPC publik, tanpa wallet).
   2. Admin menghubungkan MetaMask (harus wallet pemilik kontrak).
   3. MULAI: daftar nomor paslon dari database dikunci ke kontrak saat sesi dibuka.
   4. TUTUP (bertahap, agar tidak ada suara hilang):
        a. database berhenti menerima suara baru (status 'menutup')
        b. relayer mengirim semua sisa antrian ke blockchain (halaman ini menunggu)
        c. baru sesi ditutup di blockchain lewat MetaMask
        d. salinan status di database diperbarui ke 'selesai'
   5. Status sesi disalin ke tabel tb_sesi_voting setelah transaksi terkonfirmasi, supaya
      server bisa menolak suara di luar sesi (database tidak bisa membaca blockchain).
   ========================================================= */

// =========================================================
// NOTIFIKASI (TOAST) — slide masuk dari kanan bawah layar.
// Ditulis langsung di halaman ini, tidak bergantung pada file lain.
// Pemakaian: showToast("success" | "error" | "info", "pesan");
// Tampilannya diatur di css/style.css (bagian TOAST).
// =========================================================
function showToast(type, message) {
  let box = document.getElementById("toast-container");
  if (!box) {
    box = document.createElement("div");
    box.id = "toast-container";
    box.className = "toast-container";
    document.body.appendChild(box);
  }

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.setAttribute("role", type === "error" ? "alert" : "status");

  const icon = document.createElement("span");
  icon.className = "toast-icon";
  icon.style.cssText = "width:18px;text-align:center;font-weight:700";
  icon.textContent = type === "success" ? "\u2713" : type === "error" ? "!" : "i";

  const text = document.createElement("p");
  text.className = "toast-message";
  text.textContent = message; // textContent: aman dari HTML injection

  const close = document.createElement("button");
  close.type = "button";
  close.className = "toast-close";
  close.setAttribute("aria-label", "Tutup notifikasi");
  close.textContent = "\u00d7";

  toast.append(icon, text, close);
  box.appendChild(toast);
  while (box.children.length > 4) box.firstElementChild.remove(); // maksimal 4 sekaligus

  // Hilang otomatis; berhenti dihitung saat kursor di atas toast supaya sempat dibaca
  const dismiss = () => {
    toast.classList.remove("toast-show");
    setTimeout(() => toast.remove(), 450);
  };
  let timer = setTimeout(dismiss, type === "error" ? 6500 : 4000);
  toast.addEventListener("mouseenter", () => clearTimeout(timer));
  toast.addEventListener("mouseleave", () => {
    timer = setTimeout(dismiss, 2500);
  });
  close.addEventListener("click", () => {
    clearTimeout(timer);
    dismiss();
  });

  // Class "toast-show" ditambahkan di frame berikutnya agar transisi slide berjalan
  requestAnimationFrame(() => requestAnimationFrame(() => toast.classList.add("toast-show")));
}

// ---------------------------------------------------------
// Konstanta, elemen & state
// ---------------------------------------------------------
const RELAYER_STALE_MS = 90 * 1000; // relayer menulis detak jantung tiap ~20 detik
const LIVE_REFRESH_MS = 15 * 1000; // pembaruan otomatis ringkasan antrian & relayer
const QUEUE_POLL_MS = 4000; // saat menunggu antrian kosong ketika menutup sesi

const byId = (id) => document.getElementById(id);

const el = {
  configAlert: byId("config-alert"),
  badge: byId("session-badge"),
  openedInfo: byId("opened-info"),
  closedInfo: byId("closed-info"),
  ownerInfo: byId("owner-info"),
  contractInfo: byId("contract-info"),
  networkInfo: byId("network-info"),
  dbInfo: byId("db-info"),
  btnOpen: byId("btn-open"),
  btnClose: byId("btn-close"),
  btnCancelClose: byId("btn-cancel-close"),
  hint: byId("action-hint"),
  refreshBtn: byId("refresh-btn"),
  walletAddress: byId("wallet-address"),
  walletChips: byId("wallet-chips"),
  walletHelp: byId("wallet-help"),
  btnConnect: byId("btn-connect"),
  btnSwitch: byId("btn-switch"),
  relayerChain: byId("relayer-chain"),
  relayerLive: byId("relayer-live"),
  queueInfo: byId("queue-info"),
  chainVotes: byId("chain-votes"),
  votedInfo: byId("voted-info"),
  verifyInfo: byId("verify-info"),
  relayerInput: byId("relayer-input"),
  btnSetRelayer: byId("btn-set-relayer"),
  relayerHint: byId("relayer-hint"),
  resultsPanel: byId("results-panel"),
  resultsBody: byId("results-body"),
  resultsNote: byId("results-note"),
  overlay: byId("tx-overlay"),
  modal: byId("tx-modal"),
  viewConfirm: byId("tx-view-confirm"),
  viewProgress: byId("tx-view-progress"),
  title: byId("tx-title"),
  text: byId("tx-text"),
  points: byId("tx-points"),
  warning: byId("tx-warning"),
  btnCancel: byId("tx-cancel"),
  btnConfirm: byId("tx-confirm"),
  progressTitle: byId("tx-progress-title"),
  steps: byId("tx-steps"),
  note: byId("tx-note"),
  result: byId("tx-result"),
  btnAbort: byId("tx-abort"),
  btnClose2: byId("tx-close"),
};

let chainState = null; // keadaan sesi dari blockchain
let chainError = null;
let chainResults = null; // { numbers, counts } (hanya dibaca setelah sesi ditutup)
let dbState = null; // baris tb_sesi_voting
let dbError = null;
let syncError = null;
let kandidatDb = null; // daftar kandidat dari database (null = gagal dibaca)
let relayerRow = null; // baris tb_status_relayer (detak jantung relayer)
let summaryBefore = null; // ringkasan antrian SEBELUM membaca blockchain
let summaryAfter = null; // ringkasan antrian SESUDAH membaca blockchain
let wallet = null; // { provider, address, chainId }
let busy = false; // true selama aksi diproses
let pendingAction = null; // "open" | "close" | "relayer"
let pendingNumbers = []; // nomor paslon yang akan dikunci saat membuka sesi
let pendingRelayerAddress = null;
let currentStep = null;
let abortRequested = false;
let lastFocusedEl = null;
let walletListenersAttached = false;

const STATUS_LABEL = { 0: "Belum dimulai", 1: "Sedang berlangsung", 2: "Telah ditutup" };
const DB_LABEL = {
  belum_mulai: "Belum dimulai",
  berlangsung: "Sedang berlangsung",
  menutup: "Sedang ditutup (menunggu antrian suara kosong)",
  selesai: "Telah ditutup",
};

const STEP_LABEL = {
  stop: "Menghentikan penerimaan suara baru",
  flush: "Mengirim sisa suara ke blockchain",
  wallet: "Konfirmasi di MetaMask",
  chain: "Menunggu konfirmasi jaringan blockchain",
  db: "Memperbarui database",
};

const ACTIONS = {
  open: {
    title: "Mulai Sesi Voting?",
    text: "Anda akan membuka sesi pemilihan Ketua HMTI di blockchain.",
    points: [
      "Mahasiswa yang sudah disetujui dapat langsung memberikan suara.",
      "Pembukaan sesi dicatat permanen bersama alamat wallet Anda dan waktunya.",
      "Anda perlu mengonfirmasi transaksi di MetaMask dan membayar biaya gas.",
    ],
    warning: "Pastikan data kandidat sudah lengkap dan benar sebelum memulai.",
    danger: false,
    confirmLabel: "Ya, Mulai Sesi",
    confirmClass: "btn-primary",
    progressTitle: "Membuka sesi voting",
    steps: ["wallet", "chain", "db"],
    confirmState: (s) => s.status === 1,
    success: "Sesi voting berhasil dibuka.",
  },
  close: {
    title: "Tutup Sesi Voting?",
    text: "Anda akan menutup sesi pemilihan Ketua HMTI secara permanen.",
    points: [
      "Penerimaan suara baru dihentikan, lalu semua sisa suara di antrian dikirim ke blockchain oleh relayer (relayer harus berjalan).",
      "Setelah antrian kosong, sesi ditutup di blockchain dan TIDAK dapat dibuka kembali.",
      "Mahasiswa tidak dapat lagi memberikan suara. Hasil akhir dapat dilihat semua orang.",
    ],
    warning: "Tindakan ini tidak dapat dibatalkan setelah transaksi penutupan dikonfirmasi. Pastikan pemilihan memang sudah selesai.",
    danger: true,
    confirmLabel: "Ya, Tutup Sesi",
    confirmClass: "btn-danger-solid",
    progressTitle: "Menutup sesi voting",
    steps: ["stop", "flush", "wallet", "chain", "db"],
    confirmState: (s) => s.status === 2,
    success: "Sesi voting berhasil ditutup.",
  },
  relayer: {
    title: "Ganti Relayer?",
    text: "",
    points: [
      "Hanya alamat ini yang dapat mengirim suara ke blockchain.",
      "Relayer sebelumnya langsung tidak berlaku lagi.",
      "Anda perlu mengonfirmasi transaksi di MetaMask dan membayar biaya gas.",
    ],
    warning:
      "Pastikan Anda memegang private key alamat tersebut dan memperbarui file .env relayer. Jika salah alamat, suara tidak bisa terkirim sampai relayer diganti lagi.",
    danger: false,
    confirmLabel: "Ya, Ganti Relayer",
    confirmClass: "btn-primary",
    progressTitle: "Mengganti relayer",
    steps: ["wallet", "chain"],
    confirmState: (s) => sameAddress(s.relayer, pendingRelayerAddress),
    success: "Relayer berhasil diganti.",
  },
};

const DEFAULT_RELAYER_HINT =
  "Gunakan jika wallet relayer lama hilang atau rusak. Hanya wallet pemilik kontrak yang bisa mengganti relayer.";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ---------------------------------------------------------
// Inisialisasi & pemuatan data
// ---------------------------------------------------------
async function init() {
  el.networkInfo.textContent = `${BLOCKCHAIN.CHAIN_NAME} (ID ${BLOCKCHAIN.CHAIN_ID})`;
  el.contractInfo.textContent = BLOCKCHAIN.CONTRACT_ADDRESS || "Belum diisi";

  const problem = blockchainConfigProblem();
  if (problem) {
    el.configAlert.textContent = problem;
    el.configAlert.className = "status-msg error";
    chainError = problem;
    render();
    return;
  }

  await restoreWallet();
  await loadAll();

  // Pembaruan otomatis ringan (ringkasan antrian, detak relayer, status chain)
  setInterval(async () => {
    if (busy || document.hidden) return;
    await loadLive();
    render();
  }, LIVE_REFRESH_MS);
}

async function loadAll() {
  setBadge("loading", "Memuat...");
  await Promise.all([loadDb(), loadKandidatDb()]);
  await loadLive();
  await autoSync();
  render();
}

// Urutan penting untuk pemeriksaan konsistensi: ringkasan database dibaca SEBELUM dan
// SESUDAH membaca blockchain (lihat verifyConsistency).
async function loadLive() {
  summaryBefore = await fetchSummary();
  await loadChain(getReadProvider());
  summaryAfter = await fetchSummary();
  await loadRelayerRow();
  if (chainState && chainState.status === 2) await loadResults();
}

async function loadChain(runner) {
  try {
    chainState = await readSessionState(getSessionContract(runner));
    chainError = null;
  } catch (e) {
    chainState = null;
    chainError = describeChainError(e).message;
  }
}

async function loadResults() {
  try {
    chainResults = await readResults(getSessionContract(getReadProvider()));
  } catch (e) {
    chainResults = null;
  }
}

async function loadDb() {
  const { data, error } = await sb.from("tb_sesi_voting").select("*").eq("id", 1).single();
  if (error || !data) {
    dbState = null;
    dbError = error ? error.message : "Baris status sesi tidak ditemukan. Jalankan schema.sql terbaru.";
  } else {
    dbState = data;
    dbError = null;
  }
}

async function loadKandidatDb() {
  const { data, error } = await sb
    .from("tb_kandidat")
    .select("nomor_paslon, nama_ketua, nama_wakil")
    .order("nomor_paslon", { ascending: true });
  kandidatDb = error ? null : data || [];
}

async function loadRelayerRow() {
  const { data, error } = await sb.from("tb_status_relayer").select("*").eq("id", 1).single();
  relayerRow = error || !data ? null : data;
}

// Ringkasan jumlah (tanpa identitas): mahasiswa yang sudah memilih & isi antrian.
async function fetchSummary() {
  const { data, error } = await sb.rpc("fn_ringkasan_suara");
  if (error || !data) return null;
  return {
    sudahMemilih: Number(data.sudah_memilih),
    menunggu: Number(data.menunggu),
    diproses: Number(data.diproses),
    terkirim: Number(data.terkirim),
  };
}

function needsSync(chain, db) {
  // 'menutup' hanya ada di database (tahap peralihan); blockchain masih 'berlangsung'.
  const statusSelaras =
    db.status === chain.statusKey || (db.status === "menutup" && chain.statusKey === "berlangsung");
  return !statusSelaras || (chain.openedAt && !db.dibuka_pada) || (chain.closedAt && !db.ditutup_pada);
}

// Salinan di database mengikuti blockchain (bukan sebaliknya).
async function autoSync() {
  syncError = null;
  if (!chainState || !dbState || !needsSync(chainState, dbState)) return;
  try {
    dbState = await syncDatabase(chainState, null, null);
    showToast("info", "Status database disinkronkan dengan blockchain.");
  } catch (e) {
    syncError = e.message;
  }
}

async function syncDatabase(state, txHash, action) {
  const payload = { status: state.statusKey, diperbarui_pada: new Date().toISOString() };
  if (state.openedAt) {
    payload.dibuka_pada = unixToIso(state.openedAt);
    payload.dibuka_oleh = state.openedBy;
  }
  if (state.closedAt) {
    payload.ditutup_pada = unixToIso(state.closedAt);
    payload.ditutup_oleh = state.closedBy;
  }
  if (txHash && action === "open") payload.dibuka_tx = txHash;
  if (txHash && action === "close") payload.ditutup_tx = txHash;

  const { data, error } = await sb.from("tb_sesi_voting").update(payload).eq("id", 1).select();
  if (error) throw new Error(error.message);
  if (!data || data.length === 0) {
    throw new Error("Database menolak pembaruan. Pastikan Anda login sebagai admin dan schema.sql terbaru sudah dijalankan.");
  }
  return data[0];
}

// Mengubah HANYA status di database (dipakai untuk tahap 'menutup' dan pembatalannya).
async function setDbStatus(status) {
  const { data, error } = await sb
    .from("tb_sesi_voting")
    .update({ status, diperbarui_pada: new Date().toISOString() })
    .eq("id", 1)
    .select();
  if (error) throw new Error(error.message);
  if (!data || data.length === 0) {
    throw new Error("Database menolak pembaruan. Pastikan Anda login sebagai admin.");
  }
  dbState = data[0];
}

// ---------------------------------------------------------
// Tampilan
// ---------------------------------------------------------
function setBadge(state, label) {
  el.badge.dataset.state = state;
  el.badge.textContent = label;
}

function sameAddress(a, b) {
  return !!a && !!b && a.toLowerCase() === b.toLowerCase();
}

// Penutupan sudah dimulai di database tetapi transaksi penutupan belum selesai di blockchain
function closingInProgress() {
  return !!(dbState && dbState.status === "menutup" && chainState && chainState.status === 1);
}

function relativeTime(iso) {
  const detik = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (detik < 60) return `${detik} detik lalu`;
  if (detik < 3600) return `${Math.round(detik / 60)} menit lalu`;
  return `${Math.round(detik / 3600)} jam lalu`;
}

function render() {
  // Badge status
  if (chainError) setBadge("error", "Tidak dapat dibaca");
  else if (closingInProgress()) setBadge("closing", "Sedang ditutup");
  else if (chainState) setBadge(["idle", "open", "closed"][chainState.status], STATUS_LABEL[chainState.status]);

  // Rincian
  el.openedInfo.textContent =
    chainState && chainState.openedAt
      ? `${formatChainTime(chainState.openedAt)} oleh ${shortAddress(chainState.openedBy)}`
      : "—";
  el.closedInfo.textContent =
    chainState && chainState.closedAt
      ? `${formatChainTime(chainState.closedAt)} oleh ${shortAddress(chainState.closedBy)}`
      : "—";
  el.ownerInfo.textContent = chainState ? chainState.owner : "—";

  // Salinan database
  if (dbError) el.dbInfo.textContent = `Tidak dapat dibaca: ${dbError}`;
  else if (syncError) el.dbInfo.textContent = `Belum sinkron: ${syncError}`;
  else if (dbState && chainState) {
    el.dbInfo.textContent = `${DB_LABEL[dbState.status] || dbState.status} — sinkron dengan blockchain`;
  } else if (dbState) el.dbInfo.textContent = DB_LABEL[dbState.status] || dbState.status;
  else el.dbInfo.textContent = "—";

  renderWallet();

  const gate = actionGate();
  const closing = closingInProgress();
  el.btnOpen.disabled = !(gate.canAct && chainState.status === 0);
  el.btnClose.disabled = !(gate.canAct && chainState.status === 1);
  el.btnClose.textContent = closing ? "Lanjutkan Penutupan" : "Tutup Sesi Voting";
  el.btnCancelClose.classList.toggle("hidden", !closing);
  el.btnCancelClose.disabled = busy;
  el.hint.textContent = gate.hint;

  renderRelayerPanel();
  renderResults();
}

// Syarat dasar untuk aksi yang butuh wallet pemilik kontrak
function walletGate() {
  if (blockchainConfigProblem()) {
    return { ok: false, hint: "Selesaikan pengaturan kontrak terlebih dahulu (lihat pesan di atas)." };
  }
  if (chainError) {
    return { ok: false, hint: 'Status sesi belum dapat dibaca dari blockchain. Klik "Muat ulang".' };
  }
  if (!chainState) return { ok: false, hint: "Memuat status sesi..." };
  if (busy) return { ok: false, hint: "Aksi sedang diproses..." };
  if (!wallet) return { ok: false, hint: "Hubungkan MetaMask untuk mengelola sesi." };
  if (wallet.chainId !== BLOCKCHAIN.CHAIN_ID) {
    return { ok: false, hint: `MetaMask berada di jaringan lain. Ganti ke ${BLOCKCHAIN.CHAIN_NAME}.` };
  }
  if (!sameAddress(wallet.address, chainState.owner)) {
    return {
      ok: false,
      hint: `Wallet yang terhubung bukan pemilik kontrak. Pilih akun ${shortAddress(chainState.owner)} di MetaMask.`,
    };
  }
  return { ok: true, hint: "" };
}

function actionGate() {
  if (!blockchainConfigProblem() && !chainError && chainState && chainState.status === 2) {
    return {
      canAct: false,
      hint: "Sesi sudah ditutup secara permanen dan tidak dapat dibuka kembali. Untuk pemilihan baru, deploy kontrak baru.",
    };
  }
  const gate = walletGate();
  if (!gate.ok) return { canAct: false, hint: gate.hint };

  if (chainState.status === 0) {
    if (kandidatDb && kandidatDb.length === 0) {
      return {
        canAct: false,
        hint: "Belum ada kandidat. Tambahkan kandidat di menu Kandidat sebelum memulai sesi.",
      };
    }
    return { canAct: true, hint: 'Sesi belum dimulai. Klik "Mulai Sesi Voting" untuk membuka pemilihan.' };
  }
  if (closingInProgress()) {
    return {
      canAct: true,
      hint: 'Penutupan sedang berlangsung: penerimaan suara sudah dihentikan. Klik "Lanjutkan Penutupan" untuk menyelesaikannya, atau "Batalkan penutupan" untuk membuka kembali.',
    };
  }
  return {
    canAct: true,
    hint: 'Sesi sedang berlangsung. Klik "Tutup Sesi Voting" jika pemilihan sudah selesai.',
  };
}

function chip(text, kind) {
  const span = document.createElement("span");
  span.className = `wallet-chip wallet-chip-${kind}`;
  span.textContent = text;
  return span;
}

function renderWallet() {
  el.walletChips.innerHTML = "";

  if (!window.ethereum) {
    el.walletAddress.textContent = "MetaMask tidak terdeteksi";
    el.walletHelp.textContent = "Pasang ekstensi MetaMask di browser Anda, lalu muat ulang halaman ini. ";
    const a = document.createElement("a");
    a.href = "https://metamask.io/download/";
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = "Unduh MetaMask";
    el.walletHelp.appendChild(a);
    el.btnConnect.classList.add("hidden");
    el.btnSwitch.classList.add("hidden");
    return;
  }

  if (!wallet) {
    el.walletAddress.textContent = "Belum terhubung";
    el.btnConnect.classList.remove("hidden");
    el.btnSwitch.classList.add("hidden");
    return;
  }

  el.walletAddress.textContent = wallet.address;
  el.btnConnect.classList.add("hidden");

  const rightNetwork = wallet.chainId === BLOCKCHAIN.CHAIN_ID;
  el.walletChips.appendChild(
    chip(rightNetwork ? `Jaringan: ${BLOCKCHAIN.CHAIN_NAME}` : `Jaringan salah (ID ${wallet.chainId})`, rightNetwork ? "ok" : "bad")
  );
  if (chainState) {
    const isOwner = sameAddress(wallet.address, chainState.owner);
    el.walletChips.appendChild(chip(isOwner ? "Pemilik kontrak" : "Bukan pemilik kontrak", isOwner ? "ok" : "bad"));
  }
  el.btnSwitch.textContent = `Ganti ke ${BLOCKCHAIN.CHAIN_NAME}`;
  el.btnSwitch.classList.toggle("hidden", rightNetwork);
}

// Apakah relayer terlihat aktif? -> { state: "ok" | "bad" | "idle", text }
function relayerHealth() {
  if (!relayerRow || !relayerRow.terakhir_aktif) {
    return { state: "bad", text: "Belum pernah berjalan. Jalankan relayer (lihat relayer/PANDUAN_RELAYER.md)." };
  }
  const umur = Date.now() - new Date(relayerRow.terakhir_aktif).getTime();
  const parts = [];
  let state = "ok";

  if (umur > RELAYER_STALE_MS) {
    state = "bad";
    parts.push(`Tidak aktif — terakhir terdeteksi ${relativeTime(relayerRow.terakhir_aktif)}`);
  } else {
    parts.push(`Aktif (terdeteksi ${relativeTime(relayerRow.terakhir_aktif)})`);
  }
  if (relayerRow.terakhir_kirim) parts.push(`terakhir kirim ${relativeTime(relayerRow.terakhir_kirim)}`);
  if (relayerRow.alamat_relayer && chainState && !sameAddress(relayerRow.alamat_relayer, chainState.relayer)) {
    state = "bad";
    parts.push(`PERINGATAN: wallet yang berjalan (${shortAddress(relayerRow.alamat_relayer)}) berbeda dengan relayer terdaftar`);
  }
  if (relayerRow.error_terakhir) {
    state = "bad";
    parts.push(`Error: ${relayerRow.error_terakhir}`);
  }
  return { state, text: parts.join(" · ") };
}

// Pemeriksaan: setiap suara di blockchain berasal dari satu mahasiswa yang tercatat memilih.
//   sudahMemilih(sebelum) - antrian(sebelum) <= suara di blockchain <= sudahMemilih(sesudah)
// (ringkasan dibaca sebelum dan sesudah blockchain agar perubahan di tengah pembacaan tidak
// menimbulkan peringatan palsu)
function verifyConsistency() {
  if (!chainState || !summaryBefore || !summaryAfter) return null;
  const x = chainState.totalVotes;
  const batasBawah = summaryBefore.sudahMemilih - (summaryBefore.menunggu + summaryBefore.diproses);
  return x >= batasBawah && x <= summaryAfter.sudahMemilih;
}

function renderRelayerPanel() {
  el.relayerChain.textContent = chainState ? chainState.relayer : "—";

  const health = relayerHealth();
  el.relayerLive.textContent = health.text;
  el.relayerLive.dataset.state = health.state;

  const ringkasan = summaryAfter || summaryBefore;
  el.queueInfo.textContent = ringkasan
    ? `${ringkasan.menunggu} menunggu · ${ringkasan.diproses} diproses · ${ringkasan.terkirim} terkirim`
    : "—";
  el.chainVotes.textContent = chainState ? String(chainState.totalVotes) : "—";
  el.votedInfo.textContent = summaryAfter ? String(summaryAfter.sudahMemilih) : "—";

  const konsisten = verifyConsistency();
  if (konsisten === null) {
    el.verifyInfo.textContent = "—";
    el.verifyInfo.dataset.state = "idle";
  } else if (konsisten) {
    el.verifyInfo.textContent = "Konsisten: jumlah suara di blockchain sesuai dengan jumlah mahasiswa yang memilih dan isi antrian.";
    el.verifyInfo.dataset.state = "ok";
  } else {
    el.verifyInfo.textContent =
      "TIDAK KONSISTEN: jumlah suara di blockchain tidak sesuai dengan jumlah mahasiswa yang memilih. Jika ini data uji lama, reset status memilih (lihat PANDUAN_DEPLOY.md); jika bukan, selidiki sebelum menutup sesi.";
    el.verifyInfo.dataset.state = "bad";
  }

  renderRelayerForm();
}

function renderRelayerForm() {
  const value = el.relayerInput.value.trim();
  let hint = DEFAULT_RELAYER_HINT;
  let valid = false;

  if (chainState && chainState.status === 2) {
    hint = "Sesi sudah ditutup; relayer tidak dapat diganti lagi.";
  } else {
    const gate = walletGate();
    if (!gate.ok) hint = gate.hint;
    else if (!value) hint = DEFAULT_RELAYER_HINT;
    else if (!ethers.isAddress(value)) hint = "Alamat tidak valid. Periksa kembali (diawali 0x, 42 karakter).";
    else if (sameAddress(value, chainState.relayer)) hint = "Alamat ini sudah menjadi relayer terdaftar.";
    else {
      valid = true;
      hint = 'Alamat valid. Klik "Daftarkan relayer" untuk menggantinya (perlu konfirmasi MetaMask).';
    }
  }
  el.relayerHint.textContent = hint;
  el.btnSetRelayer.disabled = !valid;
}

// Hasil akhir dibaca dari kontrak; nama paslon dari database
function renderResults() {
  const tampil = !!(chainState && chainState.status === 2 && chainResults);
  el.resultsPanel.classList.toggle("hidden", !tampil);
  if (!tampil) return;

  const total = chainResults.counts.reduce((a, b) => a + b, 0);
  const tertinggi = Math.max(...chainResults.counts);
  const pemenang = chainResults.counts.filter((c) => c === tertinggi).length === 1 && tertinggi > 0;

  el.resultsBody.innerHTML = "";
  chainResults.numbers.forEach((nomor, i) => {
    const k = (kandidatDb || []).find((x) => x.nomor_paslon === nomor);
    const jumlah = chainResults.counts[i];
    const persen = total > 0 ? ((jumlah / total) * 100).toFixed(1) : "0.0";

    const tr = document.createElement("tr");
    if (pemenang && jumlah === tertinggi) tr.className = "row-top";

    const cells = [
      String(nomor).padStart(2, "0"),
      k ? `${k.nama_ketua} & ${k.nama_wakil}` : "(data kandidat tidak ditemukan)",
      String(jumlah),
      `${persen}%`,
    ];
    cells.forEach((text, idx) => {
      const td = document.createElement("td");
      td.textContent = text;
      if (idx === 0) td.className = "strong";
      tr.appendChild(td);
    });
    el.resultsBody.appendChild(tr);
  });

  el.resultsNote.textContent =
    `Total ${total} suara, dihitung langsung oleh smart contract dan tidak dapat diubah.` +
    (!pemenang && total > 0 ? " Perolehan tertinggi sama (seri)." : "");
}

// ---------------------------------------------------------
// Wallet (MetaMask)
// ---------------------------------------------------------
function attachWalletListeners() {
  if (walletListenersAttached || !window.ethereum || !window.ethereum.on) return;
  walletListenersAttached = true;
  window.ethereum.on("accountsChanged", () => refreshWallet());
  window.ethereum.on("chainChanged", () => refreshWallet());
}

async function refreshWallet() {
  if (!window.ethereum) {
    wallet = null;
    render();
    return;
  }
  try {
    const provider = new ethers.BrowserProvider(window.ethereum, "any");
    const accounts = await provider.send("eth_accounts", []);
    if (!accounts || accounts.length === 0) {
      wallet = null;
    } else {
      const network = await provider.getNetwork();
      wallet = { provider, address: ethers.getAddress(accounts[0]), chainId: Number(network.chainId) };
    }
  } catch (e) {
    wallet = null;
  }
  render();
}

// Menyambung kembali wallet yang sudah pernah diizinkan, tanpa memunculkan popup MetaMask
async function restoreWallet() {
  if (!window.ethereum) return;
  attachWalletListeners();
  await refreshWallet();
}

async function connectWallet() {
  if (!window.ethereum) {
    showToast("error", "MetaMask tidak terdeteksi di browser ini.");
    render();
    return;
  }
  try {
    const provider = new ethers.BrowserProvider(window.ethereum, "any");
    await provider.send("eth_requestAccounts", []);
    attachWalletListeners();
    await refreshWallet();
    if (wallet) showToast("success", `Wallet terhubung: ${shortAddress(wallet.address)}`);
  } catch (e) {
    const d = describeChainError(e);
    showToast(d.type, d.type === "info" ? "Koneksi wallet dibatalkan." : d.message);
  }
}

async function switchNetwork() {
  const chainIdHex = "0x" + BLOCKCHAIN.CHAIN_ID.toString(16);
  try {
    await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: chainIdHex }] });
  } catch (e) {
    const code = e && (e.code || (e.data && e.data.originalError && e.data.originalError.code));
    if (code === 4902) {
      // Jaringan belum ada di MetaMask: tambahkan lalu pindah
      try {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: chainIdHex,
              chainName: BLOCKCHAIN.CHAIN_NAME,
              rpcUrls: [BLOCKCHAIN.RPC_URL],
              nativeCurrency: BLOCKCHAIN.NATIVE_CURRENCY,
              blockExplorerUrls: BLOCKCHAIN.EXPLORER_URL ? [BLOCKCHAIN.EXPLORER_URL] : undefined,
            },
          ],
        });
      } catch (e2) {
        const d = describeChainError(e2);
        showToast(d.type, d.type === "info" ? "Penambahan jaringan dibatalkan." : d.message);
        return;
      }
    } else {
      const d = describeChainError(e);
      showToast(d.type, d.type === "info" ? "Pergantian jaringan dibatalkan." : d.message);
      return;
    }
  }
  await refreshWallet();
}

// ---------------------------------------------------------
// Popup konfirmasi
// ---------------------------------------------------------
function openConfirm(action) {
  const button = action === "open" ? el.btnOpen : action === "close" ? el.btnClose : el.btnSetRelayer;
  if (busy || button.disabled) return;

  const cfg = ACTIONS[action];
  let text = cfg.text;
  const points = cfg.points.slice();

  if (action === "open") {
    // Nomor paslon dikunci permanen di kontrak saat sesi dibuka
    const daftar = kandidatDb || [];
    if (daftar.length === 0) {
      showToast("error", "Belum ada kandidat. Tambahkan kandidat di menu Kandidat dulu.");
      return;
    }
    pendingNumbers = daftar.map((k) => k.nomor_paslon);
    points.unshift(
      `Kandidat yang akan dikunci: ${daftar.map((k) => `Paslon ${k.nomor_paslon}`).join(", ")}. Setelah sesi dibuka, data kandidat tidak dapat diubah atau dihapus.`
    );
  }

  if (action === "close" && closingInProgress()) {
    text = "Penutupan sudah dimulai (penerimaan suara baru sudah dihentikan). Anda akan melanjutkannya.";
  }

  if (action === "relayer") {
    pendingRelayerAddress = ethers.getAddress(el.relayerInput.value.trim());
    text = `Anda akan mendaftarkan ${pendingRelayerAddress} sebagai relayer.`;
  }

  pendingAction = action;
  lastFocusedEl = document.activeElement;

  el.title.textContent = cfg.title;
  el.text.textContent = text;
  el.points.innerHTML = "";
  points.forEach((p) => {
    const li = document.createElement("li");
    li.textContent = p;
    el.points.appendChild(li);
  });
  el.warning.textContent = cfg.warning;
  el.warning.classList.toggle("danger", cfg.danger);
  el.btnConfirm.textContent = cfg.confirmLabel;
  el.btnConfirm.className = cfg.confirmClass;
  el.btnConfirm.disabled = false;

  el.viewConfirm.classList.remove("hidden");
  el.viewProgress.classList.add("hidden");
  el.overlay.classList.remove("hidden");
  el.btnCancel.focus(); // fokus awal di aksi yang aman, bukan di tombol eksekusi
}

function closeModal() {
  if (busy) return;
  el.overlay.classList.add("hidden");
  pendingAction = null;
  if (lastFocusedEl) lastFocusedEl.focus();
}

// ---------------------------------------------------------
// Progres & eksekusi aksi
// ---------------------------------------------------------
function renderSteps(steps) {
  el.steps.innerHTML = "";
  steps.forEach((name) => {
    const li = document.createElement("li");
    li.dataset.step = name;
    li.dataset.state = "pending";
    li.textContent = STEP_LABEL[name];
    el.steps.appendChild(li);
  });
}

function setStep(name, state) {
  if (state === "active") currentStep = name;
  const li = el.steps.querySelector(`[data-step="${name}"]`);
  if (li) li.dataset.state = state;
}

function setNote(text) {
  el.note.textContent = text || "";
  el.note.classList.toggle("hidden", !text);
}

function showResult(type, message, txHash) {
  el.result.className = `status-msg ${type}`;
  el.result.textContent = message;
  if (txHash && BLOCKCHAIN.EXPLORER_URL) {
    const a = document.createElement("a");
    a.href = `${BLOCKCHAIN.EXPLORER_URL}/tx/${txHash}`;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = "Lihat transaksi";
    el.result.append(" ", a);
  }
  el.btnClose2.classList.remove("hidden");
  el.btnClose2.focus();
}

function showProgress(cfg) {
  el.viewConfirm.classList.add("hidden");
  el.viewProgress.classList.remove("hidden");
  el.progressTitle.textContent = cfg.progressTitle;
  el.result.className = "status-msg hidden";
  el.btnClose2.classList.add("hidden");
  el.btnAbort.classList.add("hidden");
  el.btnAbort.disabled = false;
  setNote("");
  renderSteps(cfg.steps);
  currentStep = null;
}

function buildCall(contract, action) {
  if (action === "open") return { method: contract.openSession, args: [pendingNumbers] };
  if (action === "close") return { method: contract.closeSession, args: [] };
  return { method: contract.setRelayer, args: [pendingRelayerAddress] };
}

// Membaca status terbaru lewat provider wallet (agar tidak tertinggal dari RPC publik)
async function readBack(cfg) {
  for (let attempt = 0; attempt < 4; attempt++) {
    const state = await readSessionState(getSessionContract(wallet.provider));
    if (cfg.confirmState(state)) return state;
    await sleep(1000);
  }
  throw new Error('Transaksi terkonfirmasi, tetapi status terbaru belum terbaca. Klik "Muat ulang" beberapa saat lagi.');
}

// Tidur yang bisa dibatalkan (untuk tombol "Batalkan penutupan")
async function sleepAbortable(ms) {
  const mulai = Date.now();
  while (Date.now() - mulai < ms) {
    if (abortRequested) return;
    await sleep(250);
  }
}

// Tahap penutupan: hentikan suara baru di database, lalu tunggu relayer mengosongkan antrian.
async function prepareClose() {
  setStep("stop", "active");
  if (!dbState || dbState.status === "berlangsung") await setDbStatus("menutup");
  render();
  setStep("stop", "done");

  setStep("flush", "active");
  abortRequested = false;
  el.btnAbort.classList.remove("hidden");
  try {
    for (; ;) {
      if (abortRequested) throw { aborted: true };

      let sisa = null;
      try {
        const s = await fetchSummary();
        if (s) sisa = s.menunggu + s.diproses;
        await loadRelayerRow();
      } catch (e) {
        sisa = null;
      }

      if (sisa === 0) break;

      const health = relayerHealth();
      let pesan =
        sisa === null
          ? "Gagal membaca isi antrian, mencoba lagi..."
          : `Menunggu ${sisa} suara terkirim ke blockchain oleh relayer...`;
      if (health.state === "bad") {
        pesan += " Relayer tampak tidak aktif atau bermasalah: jalankan relayer, atau batalkan penutupan.";
      }
      setNote(pesan);

      await sleepAbortable(QUEUE_POLL_MS);
    }
  } finally {
    el.btnAbort.classList.add("hidden");
    setNote("");
  }
  setStep("flush", "done");
  currentStep = null;
}

async function handleAbort() {
  setStep("flush", "error");
  try {
    await setDbStatus("berlangsung");
    render();
    showResult("info", "Penutupan dibatalkan. Sesi kembali berlangsung dan mahasiswa dapat memilih lagi.");
    showToast("info", "Penutupan dibatalkan.");
  } catch (err) {
    render();
    showResult("error", `Gagal membatalkan penutupan: ${err.message} Coba klik "Batalkan penutupan" di halaman ini.`);
  }
}

async function runAction() {
  if (busy || !pendingAction || !wallet) return;
  const action = pendingAction;
  const cfg = ACTIONS[action];

  busy = true;
  render();
  showProgress(cfg);

  let txHash = null;
  try {
    if (action === "close") await prepareClose();

    // 1) Simulasi dulu (tanpa biaya): jika kontrak akan menolak, pesannya jelas dan admin
    //    tidak membuang gas untuk transaksi yang pasti gagal.
    setStep("wallet", "active");
    const signer = await wallet.provider.getSigner(wallet.address);
    const contract = getSessionContract(signer);
    const call = buildCall(contract, action);
    await call.method.staticCall(...call.args);

    // 2) Kirim transaksi -> MetaMask meminta konfirmasi admin di sini
    const tx = await call.method(...call.args);
    txHash = tx.hash;
    setStep("wallet", "done");

    // 3) Tunggu terkonfirmasi di jaringan
    setStep("chain", "active");
    const receipt = await tx.wait();
    if (!receipt || receipt.status !== 1) throw new Error("Transaksi gagal di blockchain.");
    setStep("chain", "done");
    currentStep = null; // transaksi sudah sah di blockchain; kegagalan berikutnya bukan kegagalan tahap ini

    // 4) Baca status terbaru
    const state = await readBack(cfg);
    chainState = state;
    chainError = null;

    // 5) Simpan salinan ke database (hanya untuk buka/tutup sesi)
    if (cfg.steps.includes("db")) {
      setStep("db", "active");
      dbState = await syncDatabase(state, txHash, action);
      syncError = null;
      setStep("db", "done");
    }

    busy = false;
    render();
    showResult("success", cfg.success, txHash);
    showToast("success", cfg.success);

    if (action === "relayer") el.relayerInput.value = "";
    loadLive()
      .then(render)
      .catch(() => { });
  } catch (e) {
    busy = false;

    if (e && e.aborted) {
      await handleAbort();
      return;
    }

    if (currentStep) setStep(currentStep, "error");

    const d = describeChainError(e);
    let message = d.message;
    // Gagal di tahap database padahal transaksi sudah berhasil di blockchain
    if (currentStep === "db") {
      message = `Transaksi berhasil di blockchain, tetapi database gagal diperbarui: ${e.message} Muat ulang halaman ini; sinkronisasi dilakukan otomatis.`;
      syncError = e.message;
    }
    // Penutupan terhenti di tengah jalan: beri tahu keadaan dan pilihan berikutnya
    if (action === "close" && closingInProgress()) {
      message += ' Penerimaan suara sudah dihentikan. Klik "Lanjutkan Penutupan" untuk mencoba lagi, atau "Batalkan penutupan" untuk membuka kembali sesi.';
    }

    render();
    showResult(d.type === "info" ? "info" : "error", message, txHash);
    showToast(d.type === "info" ? "info" : "error", d.type === "info" ? "Transaksi dibatalkan." : "Proses tidak selesai.");
  }
}

// ---------------------------------------------------------
// Event
// ---------------------------------------------------------
el.btnConnect.addEventListener("click", connectWallet);
el.btnSwitch.addEventListener("click", switchNetwork);

el.refreshBtn.addEventListener("click", async () => {
  if (busy) return;
  if (blockchainConfigProblem()) return;
  await loadAll();
  showToast("info", "Data diperbarui dari blockchain dan database.");
});

el.btnOpen.addEventListener("click", () => openConfirm("open"));
el.btnClose.addEventListener("click", () => openConfirm("close"));
el.btnSetRelayer.addEventListener("click", () => openConfirm("relayer"));
el.relayerInput.addEventListener("input", renderRelayerForm);

el.btnCancelClose.addEventListener("click", async () => {
  if (busy || !closingInProgress()) return;
  el.btnCancelClose.disabled = true;
  try {
    await setDbStatus("berlangsung");
    showToast("info", "Penutupan dibatalkan. Sesi kembali berlangsung.");
  } catch (e) {
    showToast("error", `Gagal membatalkan penutupan: ${e.message}`);
  }
  render();
});

el.btnCancel.addEventListener("click", closeModal);
el.btnConfirm.addEventListener("click", runAction);
el.btnClose2.addEventListener("click", closeModal);
el.btnAbort.addEventListener("click", () => {
  abortRequested = true;
  el.btnAbort.disabled = true;
  setNote("Membatalkan penutupan...");
});

// Klik di luar kotak = batal (hanya saat belum memproses)
el.overlay.addEventListener("click", (e) => {
  if (e.target === el.overlay && !busy && !el.viewConfirm.classList.contains("hidden")) closeModal();
});

document.addEventListener("keydown", (e) => {
  if (el.overlay.classList.contains("hidden")) return;

  if (e.key === "Escape" && !busy) {
    closeModal();
    return;
  }

  // Jaga fokus keyboard tetap di dalam popup
  if (e.key === "Tab") {
    const focusables = Array.from(el.modal.querySelectorAll("button:not([disabled])")).filter(
      (b) => b.offsetParent !== null
    );
    if (focusables.length === 0) return;
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
});

// Halaman hanya dimuat setelah penjagaan akses admin (Sidebar.js) selesai
(window.adminReady || Promise.resolve(true)).then((ok) => {
  if (ok) init();
});